package com.aymmman.coverplay

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("coverplay", Context.MODE_PRIVATE)

    var mediaUri: String?
        get() = sp.getString("uri", null)
        set(v) = sp.edit().putString("uri", v).apply()

    var mediaType: String
        get() = sp.getString("type", "") ?: ""
        set(v) = sp.edit().putString("type", v).apply()

    var mediaName: String
        get() = sp.getString("name", "") ?: ""
        set(v) = sp.edit().putString("name", v).apply()

    var fill: Boolean
        get() = sp.getBoolean("fill", true)
        set(v) = sp.edit().putBoolean("fill", v).apply()

    var muted: Boolean
        get() = sp.getBoolean("muted", true)
        set(v) = sp.edit().putBoolean("muted", v).apply()

    var autoStart: Boolean
        get() = sp.getBoolean("auto", true)
        set(v) = sp.edit().putBoolean("auto", v).apply()

    var dimInner: Boolean
        get() = sp.getBoolean("dim", false)
        set(v) = sp.edit().putBoolean("dim", v).apply()
}
