package com.aymmman.coverplay

import android.content.Context
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

/** The view shown on the cover screen. Plays a looping video, or an animated GIF / image. */
class CoverMediaView(context: Context) : FrameLayout(context) {

    private var player: ExoPlayer? = null
    private var animated: AnimatedImageDrawable? = null

    init {
        setBackgroundColor(Color.BLACK)
        keepScreenOn = true
    }

    fun load(prefs: Prefs) {
        release()
        removeAllViews()
        val uriString = prefs.mediaUri
        if (uriString.isNullOrEmpty()) {
            showMessage("Choose a video or GIF in CoverPlay")
            return
        }
        val uri = Uri.parse(uriString)
        if (prefs.mediaType.startsWith("video/")) showVideo(uri, prefs) else showImage(uri, prefs)
    }

    @OptIn(UnstableApi::class)
    private fun showVideo(uri: Uri, prefs: Prefs) {
        val exo = ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            repeatMode = Player.REPEAT_MODE_ONE
            volume = if (prefs.muted) 0f else 1f
            prepare()
            playWhenReady = true
        }
        player = exo
        val pv = PlayerView(context).apply {
            useController = false
            setShutterBackgroundColor(Color.BLACK)
            resizeMode = if (prefs.fill) AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                         else AspectRatioFrameLayout.RESIZE_MODE_FIT
            this.player = exo
        }
        addView(pv, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    private fun showImage(uri: Uri, prefs: Prefs) {
        val iv = ImageView(context).apply {
            scaleType = if (prefs.fill) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER
        }
        addView(iv, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        Thread {
            val drawable: Drawable? = try {
                ImageDecoder.decodeDrawable(ImageDecoder.createSource(context.contentResolver, uri))
            } catch (e: Exception) {
                null
            }
            post {
                if (drawable == null) {
                    showMessage("Couldn't open this file. Pick it again.")
                    return@post
                }
                iv.setImageDrawable(drawable)
                if (drawable is AnimatedImageDrawable) {
                    drawable.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                    drawable.start()
                    animated = drawable
                }
            }
        }.start()
    }

    private fun showMessage(text: String) {
        removeAllViews()
        val tv = TextView(context).apply {
            this.text = text
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = android.view.Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }
        addView(tv, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    fun pause() {
        player?.pause()
        animated?.stop()
    }

    fun resume() {
        player?.play()
        animated?.start()
    }

    fun release() {
        player?.release()
        player = null
        animated?.stop()
        animated = null
    }
}
