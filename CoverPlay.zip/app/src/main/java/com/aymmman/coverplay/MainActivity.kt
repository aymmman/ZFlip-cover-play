@file:OptIn(androidx.window.core.ExperimentalWindowApi::class)

package com.aymmman.coverplay

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.window.area.WindowAreaCapability
import androidx.window.area.WindowAreaController
import androidx.window.area.WindowAreaInfo
import androidx.window.area.WindowAreaPresentationSessionCallback
import androidx.window.area.WindowAreaSessionPresenter
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity(), WindowAreaPresentationSessionCallback {

    private lateinit var prefs: Prefs
    private lateinit var controller: WindowAreaController
    private val executor by lazy { ContextCompat.getMainExecutor(this) }

    private var rearArea: WindowAreaInfo? = null
    private var status: WindowAreaCapability.Status = WindowAreaCapability.Status.WINDOW_AREA_STATUS_UNKNOWN
    private var session: WindowAreaSessionPresenter? = null
    private var coverView: CoverMediaView? = null
    private var wantRunning = false

    private lateinit var statusText: TextView
    private lateinit var mediaText: TextView
    private lateinit var btnToggle: MaterialButton

    private val pickMedia = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onMediaPicked(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        statusText = findViewById(R.id.statusText)
        mediaText = findViewById(R.id.mediaText)
        btnToggle = findViewById(R.id.btnToggle)

        findViewById<MaterialButton>(R.id.btnPick).setOnClickListener {
            pickMedia.launch(arrayOf("video/*", "image/gif", "image/*"))
        }
        btnToggle.setOnClickListener { if (session != null) stopCover() else startCover() }

        bindSwitch(R.id.swFill, prefs.fill) { prefs.fill = it; reloadCover() }
        bindSwitch(R.id.swMute, prefs.muted) { prefs.muted = it; reloadCover() }
        bindSwitch(R.id.swAuto, prefs.autoStart) { prefs.autoStart = it }
        bindSwitch(R.id.swDim, prefs.dimInner) { prefs.dimInner = it; applyInnerScreen() }

        controller = WindowAreaController.getOrCreate()
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                controller.windowAreaInfos.collect { infos ->
                    val area = infos.firstOrNull { it.type == WindowAreaInfo.Type.TYPE_REAR_FACING }
                    rearArea = area
                    status = area?.getCapability(WindowAreaCapability.Operation.OPERATION_PRESENT_ON_AREA)?.status
                        ?: WindowAreaCapability.Status.WINDOW_AREA_STATUS_UNSUPPORTED
                    if (wantRunning && session == null &&
                        status == WindowAreaCapability.Status.WINDOW_AREA_STATUS_AVAILABLE
                    ) startCover()
                    updateUi()
                }
            }
        }
        updateUi()
    }

    override fun onStart() {
        super.onStart()
        if (prefs.autoStart && !prefs.mediaUri.isNullOrEmpty()) wantRunning = true
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) {
            session?.close()
        }
    }

    override fun onDestroy() {
        session?.close()
        coverView?.release()
        super.onDestroy()
    }

    private fun bindSwitch(id: Int, value: Boolean, onChange: (Boolean) -> Unit) {
        findViewById<MaterialSwitch>(id).apply {
            isChecked = value
            setOnCheckedChangeListener { _, checked -> onChange(checked) }
        }
    }

    private fun onMediaPicked(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: SecurityException) { }
        prefs.mediaUri = uri.toString()
        prefs.mediaType = contentResolver.getType(uri) ?: ""
        prefs.mediaName = queryName(uri)
        updateUi()
        if (session != null) reloadCover() else startCover()
    }

    private fun queryName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: ""
        }
        return uri.lastPathSegment ?: ""
    }

    private fun startCover() {
        if (prefs.mediaUri.isNullOrEmpty()) {
            toast("Choose a video or GIF first")
            return
        }
        wantRunning = true
        if (session != null) return
        val area = rearArea
        if (area == null || status != WindowAreaCapability.Status.WINDOW_AREA_STATUS_AVAILABLE) {
            updateUi()
            return
        }
        controller.presentContentOnWindowArea(area.token, this, executor, this)
    }

    private fun stopCover() {
        wantRunning = false
        session?.close()
    }

    private fun reloadCover() {
        coverView?.load(prefs)
    }

    // Cover screen session callbacks

    override fun onSessionStarted(session: WindowAreaSessionPresenter) {
        this.session = session
        val view = CoverMediaView(session.context)
        coverView = view
        session.setContentView(view)
        view.load(prefs)
        applyInnerScreen()
        updateUi()
    }

    override fun onSessionEnded(t: Throwable?) {
        coverView?.release()
        coverView = null
        session = null
        applyInnerScreen()
        updateUi()
        if (t != null) toast("Cover screen stopped: ${t.message}")
    }

    override fun onContainerVisibilityChanged(isVisible: Boolean) {
        if (isVisible) coverView?.resume() else coverView?.pause()
    }

    // Inner screen: stay awake while playing, optionally dimmed

    private fun applyInnerScreen() {
        val running = session != null
        if (running) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val lp = window.attributes
        lp.screenBrightness = if (running && prefs.dimInner) 0.02f
                              else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        window.attributes = lp
    }

    private fun updateUi() {
        mediaText.text = if (prefs.mediaUri.isNullOrEmpty()) "No media selected"
                         else "Selected: ${prefs.mediaName.ifEmpty { "your file" }}"
        statusText.text = when {
            session != null -> "Playing on the cover screen"
            status == WindowAreaCapability.Status.WINDOW_AREA_STATUS_AVAILABLE -> "Cover screen ready"
            status == WindowAreaCapability.Status.WINDOW_AREA_STATUS_ACTIVE -> "Cover screen is busy"
            status == WindowAreaCapability.Status.WINDOW_AREA_STATUS_UNAVAILABLE ->
                "Cover screen not available. Open the phone fully (flat)."
            status == WindowAreaCapability.Status.WINDOW_AREA_STATUS_UNSUPPORTED ->
                "This phone doesn't allow apps to use the cover screen while open."
            else -> "Checking cover screen..."
        }
        btnToggle.text = if (session != null) "Stop" else "Start on cover screen"
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
